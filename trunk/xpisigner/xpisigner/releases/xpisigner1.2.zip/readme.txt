XPISigner

Installation

Unzip xpisigner1.2.zip to a temporary directory
if java is not on your path Edit xpisiger.cmd or xpisigner.sh to point to your java installation.
On Unix:
  chmod o+x xpisigner.sh

Running XPISigner

xpisigner.sh pfxfile password alias <baseDir|listfile> output
or
xpisigner.cmd pfxfile password alias <baseDir|listfile> output

Parameters:
	pfxfile
		The PKCS#12 file containing your signing credentials.
	password   
		The passphrase for pfxfile.
	basedir
		Include all files under basedir.
	listfile   
		Include only the files found in listfile.
	output
		Location to save the signed xpi.

