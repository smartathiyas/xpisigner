=========
XPISigner
=========

Version: 1.3
Copyright (c) Kevin O'Regan 2007

Installation
============

o Unzip xpisigner1.3.zip to a temporary directory
o If java is not on your path Edit xpisiger.cmd or xpisigner to point to your java installation.

Note: Java5 is required for XPISigner to run correctly.

On Unix:
  chmod o+x xpisigner

Running XPISigner
=================


xpisigner pfxfile password alias <baseDir|listfile> output
or
xpisigner.cmd pfxfile password alias <baseDir|listfile> output

Parameters:

	pfxfile
		The PKCS#12 file containing your signing credentials.
	password   
		The passphrase for pfxfile.
	basedir
		Include all files under basedir.
	listfile   
		Include only the files found in listfile.
	output
		Location to save the signed xpi.

